create procedure
          hello_test(
            p_start in int,p_end in int,p_count out int,p_emps out sys_refcursor
          )as
begin
          select count(*) into p_count from emp;
          open p_emps for
                      select * from (select rownum rn,e.* from emp e where rownum <= p_end)
                      where rn >= p_start;
end hello_test;
/

